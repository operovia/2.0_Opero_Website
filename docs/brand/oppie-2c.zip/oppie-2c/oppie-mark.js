// <oppie-mark size="40" theme="light|dark" state="idle|thinking" duration="2.4" static></oppie-mark>
(() => {
  const SLICES = [{"col":"#d43a2f","hi":"#ff5444","lo":"#83241d","d":"M100 100L100.00 20.00A80 80 0 0 1 176.08 75.28Z","ox":1.76,"oy":-2.43,"px":5.29,"py":-7.28},{"col":"#6b3fa0","hi":"#9b5be8","lo":"#422763","d":"M100 100L176.08 75.28A80 80 0 0 1 147.02 164.72Z","ox":2.85,"oy":0.93,"px":8.56,"py":2.78},{"col":"#c58b1a","hi":"#ffca26","lo":"#7a5610","d":"M100 100L147.02 164.72A80 80 0 0 1 52.98 164.72Z","ox":0,"oy":3,"px":0,"py":9},{"col":"#2f8f5b","hi":"#44cf84","lo":"#1d5938","d":"M100 100L52.98 164.72A80 80 0 0 1 23.92 75.28Z","ox":-2.85,"oy":0.93,"px":-8.56,"py":2.78},{"col":"#1e8e9a","hi":"#2ccedf","lo":"#13585f","d":"M100 100L23.92 75.28A80 80 0 0 1 100.00 20.00Z","ox":-1.76,"oy":-2.43,"px":-5.29,"py":-7.28}];
  let n = 0;
  class OppieMark extends HTMLElement {
    static get observedAttributes() { return ["size", "theme", "state", "duration", "static"]; }
    connectedCallback() { this.render(); }
    attributeChangedCallback() { if (this.isConnected) this.render(); }
    render() {
      const p = "om" + (n++), size = this.getAttribute("size") || 40, dark = this.getAttribute("theme") === "dark";
      const thinking = this.getAttribute("state") === "thinking", anim = !this.hasAttribute("static");
      const dur = parseFloat(this.getAttribute("duration") || (thinking ? 2 : 2.4));
      const reduce = `@media (prefers-reduced-motion:reduce){.${p}b,.${p}h,[class^="${p}r"]{animation:none!important}.${p}h{opacity:0}}`;
      const css = !anim ? "" : thinking
        ? SLICES.map((s, i) => `@keyframes ${p}k${i}{0%,60%,100%{transform:translate(0,0);filter:brightness(1)}20%{transform:translate(${s.px}px,${s.py}px);filter:brightness(1.35)}}.${p}r${i}{animation:${p}k${i} ${dur}s ease-in-out ${(i*dur/5).toFixed(2)}s infinite}`).join("") + reduce
        : `@keyframes ${p}kb{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}@keyframes ${p}kh{0%,100%{opacity:0}50%{opacity:.55}}.${p}b{transform-origin:100px 100px;animation:${p}kb ${dur}s ease-in-out infinite}.${p}h{opacity:0;animation:${p}kh ${dur}s ease-in-out infinite}` + reduce;
      const hc = dark ? "#fff" : "#6b3fa0";
      const grads = SLICES.map((s, i) => `<radialGradient id="${p}g${i}" gradientUnits="userSpaceOnUse" cx="72" cy="68" r="92"><stop offset="0" stop-color="${s.hi}"/><stop offset=".5" stop-color="${s.col}"/><stop offset="1" stop-color="${s.lo}"/></radialGradient>`).join("");
      const body = SLICES.map((s, i) => `<g transform="translate(${s.ox} ${s.oy})"><g class="${thinking && anim ? p + "r" + i : ""}"><path d="${s.d}" fill="url(#${p}g${i})"/><path d="${s.d}" fill="url(#${p}s)"/></g></g>`).join("");
      const halo = !thinking && anim ? `<circle class="${p}h" cx="100" cy="100" r="98" fill="url(#${p}hg)"/>` : "";
      this.style.display = "inline-block"; this.style.lineHeight = "0";
      this.innerHTML = `<svg viewBox="-10 -10 220 220" width="${size}" height="${size}" role="img" aria-label="Oppie"><style>${css}</style><defs><radialGradient id="${p}s" cx=".34" cy=".3" r=".6"><stop offset="0" stop-color="#fff" stop-opacity=".6"/><stop offset=".45" stop-color="#fff" stop-opacity=".1"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient><radialGradient id="${p}hg"><stop offset=".55" stop-color="${hc}" stop-opacity="${dark?.35:.25}"/><stop offset="1" stop-color="${hc}" stop-opacity="0"/></radialGradient><filter id="${p}f" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="3" stdDeviation="${dark?5:3}" flood-color="#000" flood-opacity="${dark?.5:.18}"/></filter>${grads}</defs>${halo}<g class="${!thinking && anim ? p + "b" : ""}"><g filter="url(#${p}f)">${body}</g></g></svg>`;
    }
  }
  if (!customElements.get("oppie-mark")) customElements.define("oppie-mark", OppieMark);
})();
