import { useId } from "react";

// Oppie — Opero AI agent mark.
// state="idle"     → option 1a "Breathe": whole pie swells 6% with a soft halo, 2.4s cycle.
// state="thinking" → option 2c "Relay": slices push out clockwise in turn, 2.0s cycle.
// Slice order clockwise from top: Build, Studios, Playbook, University, Compass.
const SLICES = [
  {
    "name": "build",
    "col": "#d43a2f",
    "hi": "#ff5444",
    "lo": "#83241d",
    "d": "M100 100L100.00 20.00A80 80 0 0 1 176.08 75.28Z",
    "ox": 1.76,
    "oy": -2.43,
    "px": 5.29,
    "py": -7.28
  },
  {
    "name": "studios",
    "col": "#6b3fa0",
    "hi": "#9b5be8",
    "lo": "#422763",
    "d": "M100 100L176.08 75.28A80 80 0 0 1 147.02 164.72Z",
    "ox": 2.85,
    "oy": 0.93,
    "px": 8.56,
    "py": 2.78
  },
  {
    "name": "playbook",
    "col": "#c58b1a",
    "hi": "#ffca26",
    "lo": "#7a5610",
    "d": "M100 100L147.02 164.72A80 80 0 0 1 52.98 164.72Z",
    "ox": 0,
    "oy": 3,
    "px": 0,
    "py": 9
  },
  {
    "name": "university",
    "col": "#2f8f5b",
    "hi": "#44cf84",
    "lo": "#1d5938",
    "d": "M100 100L52.98 164.72A80 80 0 0 1 23.92 75.28Z",
    "ox": -2.85,
    "oy": 0.93,
    "px": -8.56,
    "py": 2.78
  },
  {
    "name": "compass",
    "col": "#1e8e9a",
    "hi": "#2ccedf",
    "lo": "#13585f",
    "d": "M100 100L23.92 75.28A80 80 0 0 1 100.00 20.00Z",
    "ox": -1.76,
    "oy": -2.43,
    "px": -5.29,
    "py": -7.28
  }
];

export default function Oppie({ size = 40, theme = "light", state = "idle", duration, animate = true, className, title = "Oppie" }) {
  const p = "op" + useId().replace(/:/g, "");
  const dark = theme === "dark";
  const thinking = state === "thinking";
  const dur = duration ?? (thinking ? 2 : 2.4);
  const reduce = `@media (prefers-reduced-motion:reduce){.${p}b,.${p}h,[class^="${p}r"]{animation:none!important}.${p}h{opacity:0}}`;
  const css = !animate ? "" : thinking
    ? SLICES.map((s, i) =>
        `@keyframes ${p}k${i}{0%,60%,100%{transform:translate(0,0);filter:brightness(1)}20%{transform:translate(${s.px}px,${s.py}px);filter:brightness(1.35)}}` +
        `.${p}r${i}{animation:${p}k${i} ${dur}s ease-in-out ${(i * dur / 5).toFixed(2)}s infinite}`).join("") + reduce
    : `@keyframes ${p}kb{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}@keyframes ${p}kh{0%,100%{opacity:0}50%{opacity:.55}}` +
      `.${p}b{transform-origin:100px 100px;animation:${p}kb ${dur}s ease-in-out infinite}.${p}h{opacity:0;animation:${p}kh ${dur}s ease-in-out infinite}` + reduce;
  const haloColor = dark ? "#fff" : "#6b3fa0";
  return (
    <svg viewBox="-10 -10 220 220" width={size} height={size} role="img" aria-label={title} className={className}>
      {css && <style>{css}</style>}
      <defs>
        <radialGradient id={p + "s"} cx=".34" cy=".3" r=".6">
          <stop offset="0" stopColor="#fff" stopOpacity=".6" /><stop offset=".45" stopColor="#fff" stopOpacity=".1" /><stop offset="1" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={p + "hg"}>
          <stop offset=".55" stopColor={haloColor} stopOpacity={dark ? 0.35 : 0.25} /><stop offset="1" stopColor={haloColor} stopOpacity="0" />
        </radialGradient>
        <filter id={p + "f"} x="-20%" y="-20%" width="140%" height="150%">
          <feDropShadow dx="0" dy="3" stdDeviation={dark ? 5 : 3} floodColor="#000" floodOpacity={dark ? 0.5 : 0.18} />
        </filter>
        {SLICES.map((s, i) => (
          <radialGradient key={i} id={p + "g" + i} gradientUnits="userSpaceOnUse" cx="72" cy="68" r="92">
            <stop offset="0" stopColor={s.hi} /><stop offset=".5" stopColor={s.col} /><stop offset="1" stopColor={s.lo} />
          </radialGradient>
        ))}
      </defs>
      {!thinking && animate && <circle className={p + "h"} cx="100" cy="100" r="98" fill={`url(#${p}hg)`} />}
      <g className={!thinking && animate ? p + "b" : undefined}>
        <g filter={`url(#${p}f)`}>
          {SLICES.map((s, i) => (
            <g key={s.name} transform={`translate(${s.ox} ${s.oy})`}>
              <g className={thinking && animate ? p + "r" + i : undefined}>
                <path d={s.d} fill={`url(#${p}g${i})`} />
                <path d={s.d} fill={`url(#${p}s)`} />
              </g>
            </g>
          ))}
        </g>
      </g>
    </svg>
  );
}
