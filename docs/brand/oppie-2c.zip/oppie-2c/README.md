# Oppie mark — idle (1a Breathe) + thinking (2c Relay)

Opero's AI agent mark: a five-slice pie in module colours, with two motion states.

- **Idle — 1a Breathe:** the whole pie swells 6% and a soft halo fades in and out, 2.4s cycle. Halo is purple (#6b3fa0, 25%) on light, white (35%) on dark.
- **Thinking — 2c Relay:** each slice pushes outward 9 units and brightens in turn, clockwise, 2.0s cycle.

Motion stops automatically under `prefers-reduced-motion`.

## Slice colours (clockwise from top)
| Module | Base | Highlight | Shadow |
|---|---|---|---|
| Build | #d43a2f | #ff5444 | #83241d |
| Studios | #6b3fa0 | #9b5be8 | #422763 |
| Playbook | #c58b1a | #ffca26 | #7a5610 |
| University | #2f8f5b | #44cf84 | #1d5938 |
| Compass | #1e8e9a | #2ccedf | #13585f |

## Files
- `oppie-idle-light.svg` / `oppie-idle-dark.svg` — animated idle state (1a).
- `oppie-thinking-light.svg` / `oppie-thinking-dark.svg` — animated thinking state (2c). (`oppie-animated-*.svg` are the same files under the earlier name.)
- `oppie-static-light.svg` / `oppie-static-dark.svg` — no motion; favicons, OG images, email, print.
- `oppie-512.png`, `oppie-192.png`, `oppie-32.png` — static raster fallbacks, transparent.
- `Oppie.jsx` — React component. Props: `state` ("idle" | "thinking", default "idle"), `size` (px, default 40), `theme` ("light" | "dark"), `duration` (seconds; defaults 2.4 idle / 2.0 thinking), `animate` (bool), `className`, `title`. React 18+.
- `oppie-mark.js` — framework-free web component: `<script src="oppie-mark.js"></script>` then `<oppie-mark state="thinking" theme="dark" size="40"></oppie-mark>`. Change the `state` attribute live to switch. Add `static` to disable motion.

## Integration notes for Claude Code
- viewBox is `-10 -10 220 220` to leave room for the outward push and shadow; the pie itself is 160 units wide centred at 100,100. Don't crop tighter or the animation clips.
- Suggested speeds from the exploration: 5.6s calm/idle, 3.3s steady, 2.0s active (this file), 1.25s rapid.
- Minimum recommended display size: 24px. Below that, use the static SVG.
- Switch states by changing `state` on the same element/component rather than swapping images, so the mark doesn't flicker or shift.
- Idle and thinking share identical geometry and viewBox, so the switch has no layout change.
